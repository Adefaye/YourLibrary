<?php






class Faye extends Ayoola_Dbase_Table_abstract_Xml_protected
{
	    /**
     * The Version of the present table (SVN COMPATIBLE)
     *
     * @param int
     */
    protected $_tableVersion = '0.09';

	protected $_dataTypes = array
	( 
		'name' => 'INPUTTEXT',
        'email' => 'INPUTTEXT',
        'comment' => 'INPUTTEXT',
		
	);
	// END OF CLASS
}



   