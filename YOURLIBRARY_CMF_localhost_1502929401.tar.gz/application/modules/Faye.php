<?php

/**
 * @package    Falola
 * @copyright  Copyright (c) 2011-2016 PageCarton (http://www.pagecarton.com)
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

class Faye extends Ayoola_Abstract_Table
{
	
    /**
     * Whether class is playable or not
     *
     * @var boolean
     */
	protected static $_playable = true;
		
    /**
     * Access level for player
     *
     * @var boolean
     */
	protected static $_accessLevel = 0;
	
    /**
     * The method does the whole Class Process
     * 
     */
	protected function init()
    {
    	$this->createForm( 'Submit Comment', 'Add a Comment' );
		$this->setViewContent( $this->getForm()->view(), true );
		if( ! $values = $this->getForm()->getValues() ){ return false; }
		$this->setViewContent( 'THANK YOU!!!'  , true );
        $this->setViewContent( 'Your comment has been submitted!!', true );

    }

	 /**
     * creates the form
     * 
     * param string The Value of the Submit Button
     * param string Value of the Legend
     * param array Default Values
     */
	public function createForm( $submitValue, $legend = null, Array $values = null ) 
    {
		//	Form to create a new page
        $form = new Ayoola_Form( array( 'name' => $this->getObjectName() ) );
		$fieldset = new Ayoola_Form_Element;
		$form->submitValue = $submitValue ;
		$fieldset->addElement( array( 'name' => 'name', 'label' => 'Name', 'placeholder' => 'Enter your name', 'type' => 'InputText', 'value' => 
                                     @$values['name'] ) );
		$fieldset->addElement( array( 'name' => 'email', 'label' => 'Email', 'placeholder' => 'Example@example.com', 'type' => 'InputText', 'value' => 
                                     @$values['email'] ) );
		$fieldset->addElement( array( 'name' => 'comment', 'label' => 'comment', 'placeholder' => 'what do you have to say', 'type' => 'TextArea', 'value' =>
                                     @$values['comment'] ) );
       
			$form->addFieldset( $fieldset );
		
		$this->setForm( $form );
    } 
	// END OF CLASS
}

