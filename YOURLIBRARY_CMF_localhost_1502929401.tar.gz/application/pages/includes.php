<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: includes.php	Monday 14th of August 2017 09:23:10 AM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_8d720768755f273465277cceaac83c40 = new Ayoola_Menu( array (
  'option' => 'menu_4',
  'new_menu_name' => '',
  'template_name' => 'HorizontalGrayish',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_8d720768755f273465277cceaac83c40 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_12cf5b0ad86882498e2147d1ba6a705a = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h1 style="text-align: center;"><span style="color:#b22222;"><span style="font-family:Georgia,serif;">WELCOME TO YOURLIBRARY!</span></span></h1>

<p><img alt="" src="/index.php/public/2017/08/14/Faye_jpg.jpg" style="float: left; width: 200px; height: 166px;">&nbsp;&nbsp;<span style="color:#800000;"><span style="font-size:18px;"><span style="font-family:Courier New,Courier,monospace;">EDUCATE YOURSELF.</span></span></span></p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#800000;">YOUNG &amp; OLD.</span></p>

<p>&nbsp;</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#000000;"><span style="font-family:Comic Sans MS,cursive;">&nbsp;KNOWLEDGE AT YOUR FINGERTIPS.</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_12cf5b0ad86882498e2147d1ba6a705a = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_c165f6adf5de182d2ebe75b6f2ef3105 = new Ayoola_Menu( array (
  'option' => 'menu_3',
  'new_menu_name' => '',
  'template_name' => 'HorizontalWhite',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_c165f6adf5de182d2ebe75b6f2ef3105 = null;

							}
							