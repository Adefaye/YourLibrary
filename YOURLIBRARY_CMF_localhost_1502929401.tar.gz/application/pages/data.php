<?php return array (
  'ay__oneness0' => 'menuView',
  'ay__oneness0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__oneness0option' => 'menu_4',
  'ay__oneness0new_menu_name' => '',
  'ay__oneness0template_name' => 'HorizontalGrayish',
  'ay__oneness0_parameters' => 'advanced_parameters,option,new_menu_name,template_name,option,new_menu_name,template_name',
  'ay__middlebar0' => 'pageEditText',
  'ay__middlebar0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__middlebar0editable' => '<h1 style="text-align: center;"><span style="color:#b22222;"><span style="font-family:Georgia,serif;">WELCOME TO YOURLIBRARY!</span></span></h1>

<p><img alt="" src="/index.php/public/2017/08/14/Faye_jpg.jpg" style="float: left; width: 200px; height: 166px;">&nbsp;&nbsp;<span style="color:#800000;"><span style="font-size:18px;"><span style="font-family:Courier New,Courier,monospace;">EDUCATE YOURSELF.</span></span></span></p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="color:#800000;">YOUNG &amp; OLD.</span></p>

<p>&nbsp;</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style="color:#000000;"><span style="font-family:Comic Sans MS,cursive;">&nbsp;KNOWLEDGE AT YOUR FINGERTIPS.</span></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>
',
  'ay__middlebar0_parameters' => 'advanced_parameters,editable,editable',
  'ay__middlebar1' => 'menuView',
  'ay__middlebar1advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-background',
  'ay__middlebar1option' => 'menu_3',
  'ay__middlebar1new_menu_name' => '',
  'ay__middlebar1template_name' => 'HorizontalWhite',
  'ay__middlebar1_parameters' => 'advanced_parameters,option,new_menu_name,template_name,option,new_menu_name,template_name',
  'section_list' => 'ay__oneness,ay__middlebar,',
);