<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /search
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: search.php	Saturday 12th of August 2017 04:54:05 PM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Application_Article_ShowAll' ) )
							{
								
$_cd3c518f1a105ccd0ee1bcd8a583ce4a = new Application_Article_ShowAll( array (
  'option' => '12',
  'category_name' => '0',
  'article_types' => '',
  'template_name' => 'ProductsforSale',
  'advanced_parameter_value' => 
  array (
    0 => 'keyword',
    1 => 'View',
  ),
  'ed045ffdd0e611afbcad3a5324a29ec00d9207' => 'advanced_parameters_object_unique_id_52a294c1060c2a3a2b06e9baeef1457c',
  'd611562fd6f9ff71e4140ba706031a36feef' => '107374182',
  'e6aecc5238a41d822bda8851b38df93b92476f' => '',
  'search_mode' => 'keyword',
  'button_value' => 'View',
) );

							}
							else
							{
								
$_cd3c518f1a105ccd0ee1bcd8a583ce4a = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_810eb9c8ffaf9531235050e5c3a4d6db = new Ayoola_Menu( array (
  'option' => 'side-bar-options',
  'template_name' => 'BlackAccordionSide-menu',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'c248ddf87eda05d1559ad6c332728e9b89c588' => 'advanced_parameters_object_unique_id_9cbabf00532a0aafa02cc612dc280824',
  'd611562fd6f9ff71e4140ba706031a36feef' => '107374182',
  'e6aecc5238a41d822bda8851b38df93b92476f' => '',
  '' => '',
) );

							}
							else
							{
								
$_810eb9c8ffaf9531235050e5c3a4d6db = null;

							}
							