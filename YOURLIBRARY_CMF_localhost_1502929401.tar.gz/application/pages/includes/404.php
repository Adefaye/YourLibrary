<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /404
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: 404.php	Saturday 12th of August 2017 04:53:48 PM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_c15064ab7dd70d6e4256417464e1d148 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h1>Error 404 - Page Not Found</h1>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'well',
  '' => '',
) );

							}
							else
							{
								
$_c15064ab7dd70d6e4256417464e1d148 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_a44960725c4e9cdaff09059689171645 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p>You are seeing this page because you have requested a page that is not available. Please check the URL and try again.</p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_a44960725c4e9cdaff09059689171645 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Object_Embed' ) )
							{
								
$_2cb92db7d1c93ec2ad288ca0dd5803c0 = new Ayoola_Object_Embed( array (
  'editable' => 'Ayoola_Page_AutoCreator',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_2cb92db7d1c93ec2ad288ca0dd5803c0 = null;

							}
							