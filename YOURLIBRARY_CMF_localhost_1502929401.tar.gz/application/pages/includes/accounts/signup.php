<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /accounts/signup
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: signup.php	Saturday 12th of August 2017 04:53:40 PM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_15bea1745da95d2132f341485bc2a5c8 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h1>Create an account</h1>

<p>&nbsp;</p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_15bea1745da95d2132f341485bc2a5c8 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Application_User_Creator' ) )
							{
								
$_669f73cbbecd29f96f461a5bd0ef64ae = new Application_User_Creator( array (
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_669f73cbbecd29f96f461a5bd0ef64ae = null;

							}
							