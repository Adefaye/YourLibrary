<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /accounts/signin
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: signin.php	Saturday 12th of August 2017 04:53:30 PM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_da572a4816c3b3a2748caf6101791ccb = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p></p>
<h1>Login</h1>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_da572a4816c3b3a2748caf6101791ccb = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Access_Login' ) )
							{
								
$_c3a3812d98ece96536773e6d290ea0dc = new Ayoola_Access_Login( array (
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_c3a3812d98ece96536773e6d290ea0dc = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_aa9e0e44eb52fcae5dbf065506a8071c = new Ayoola_Page_Editor_Text( array (
  'editable' => '<hr>
<p>Forgot Password? <a href="/object/name/Application_User_Help_ForgotUsernameOrPassword">Sign in Help</a>!</p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_aa9e0e44eb52fcae5dbf065506a8071c = null;

							}
							