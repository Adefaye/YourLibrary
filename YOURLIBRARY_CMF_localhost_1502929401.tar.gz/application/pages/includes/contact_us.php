<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /contact_us
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: contact_us.php	Monday 14th of August 2017 09:05:25 AM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_431bb7b5e2ed132e73e6b594c7cf545c = new Ayoola_Menu( array (
  'option' => 'menu_4',
  'new_menu_name' => '',
  'template_name' => 'HorizontalWhite',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_431bb7b5e2ed132e73e6b594c7cf545c = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_0b8032f5ef266358c0ab9a0befb24299 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p>Feel Free To Contact Us Through the Form Given below.</p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_0b8032f5ef266358c0ab9a0befb24299 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Application_ContactUs_Creator' ) )
							{
								
$_ab9d763b3317017ddbf6e6149bf5e18f = new Application_ContactUs_Creator( array (
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_ab9d763b3317017ddbf6e6149bf5e18f = null;

							}
							