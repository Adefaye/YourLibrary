<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /post/view
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: view.php	Saturday 12th of August 2017 04:52:28 PM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_b226e6794a4e3a4b43bd7d34567408b5 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h3 style="text-align: center;">Other Posts in this Category</h3>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_b226e6794a4e3a4b43bd7d34567408b5 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Application_Article_ShowAll' ) )
							{
								
$_fceed21ad43d516b1c84862881950402 = new Application_Article_ShowAll( array (
  'option' => '3',
  'category_name' => '',
  'article_types' => '',
  'template_name' => 'ProductsandServicesList2',
  'advanced_parameter_value' => 
  array (
    0 => '1',
  ),
  'wrapper_name' => '',
  'post_with_same_category' => '1',
) );

							}
							else
							{
								
$_fceed21ad43d516b1c84862881950402 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Object_Embed' ) )
							{
								
$_0c60e1166f359ad481cd5056798e3025 = new Ayoola_Object_Embed( array (
  'editable' => 'Application_Article_View',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_0c60e1166f359ad481cd5056798e3025 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_e7b70dd96ba050c44a32d8d1b5f7b253 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p>Please leave a comment</p>',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'well',
  '' => '',
) );

							}
							else
							{
								
$_e7b70dd96ba050c44a32d8d1b5f7b253 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Object_Embed' ) )
							{
								
$_409d607ffe767f215b0d18f336b17df1 = new Ayoola_Object_Embed( array (
  'editable' => ' Application_Facebook_Comment, Application_Disqus_Comment',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_409d607ffe767f215b0d18f336b17df1 = null;

							}
							