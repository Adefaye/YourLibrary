<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /login
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: login.php	Monday 14th of August 2017 09:08:56 AM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_573f415f2f1468ca8364f469c44f0367 = new Ayoola_Menu( array (
  'option' => 'menu_4',
  'new_menu_name' => '',
  'template_name' => 'HorizontalWhite',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_573f415f2f1468ca8364f469c44f0367 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Access_Login' ) )
							{
								
$_1af9a3bfcfc3ee531fffd07ef832102c = new Ayoola_Access_Login( array (
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_1af9a3bfcfc3ee531fffd07ef832102c = null;

							}
							