<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /account
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: account.php	Saturday 12th of August 2017 04:52:48 PM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_a6534fa081b02306edaf8bffe7816299 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h4>My Account Settings</h4>

<p><span style="font-size:12px;">Information you use to log on</span></p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_a6534fa081b02306edaf8bffe7816299 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_6bccbc3db0d8c03b873ace879949f763 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p><strong>First name</strong>: {{{firstname}}}<br>
<strong>Last name</strong>: {{{lastname}}}</p>

<p><strong>Email</strong>: {{{email}}}<br>
<strong>Password</strong>: ******</p>

<p><a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Application_User_Help_ChangePassword" rel="spotlight">Change Password</a>&nbsp;<a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Application_User_UserEmail_Editor" rel="spotlight">Manage Emails</a></p>
',
  'advanced_parameter_value' => 
  array (
    0 => 'Ayoola_Access_Dashboard',
  ),
  'wrapper_name' => 'white-background',
  'markup_template_object_name' => 'Ayoola_Access_Dashboard',
) );

							}
							else
							{
								
$_6bccbc3db0d8c03b873ace879949f763 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Object_Embed' ) )
							{
								
$_9bcd32b243a8e64ab64a362062adbb63 = new Ayoola_Object_Embed( array (
  'editable' => 'Application_User_Restrictions',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-background',
  '' => '',
) );

							}
							else
							{
								
$_9bcd32b243a8e64ab64a362062adbb63 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_0c1e19efcdef7cbdb70ec0f68614f824 = new Ayoola_Menu( array (
  'option' => 'MyAccount',
  'new_menu_name' => '',
  'template_name' => 'BlackAccordionSide-menu',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-content-theme-border',
  '' => '',
) );

							}
							else
							{
								
$_0c1e19efcdef7cbdb70ec0f68614f824 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_0a299d40642611dba9e0a908079c7971 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h4>My Profile</h4>

<p><span style="font-size:12px;">How people see you</span></p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-content-theme-border',
  '' => '',
) );

							}
							else
							{
								
$_0a299d40642611dba9e0a908079c7971 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_68d3b303c9e476d9fed3cacb365c4e00 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p style="text-align: center;"><img alt="Display Picture" src="{{{display_picture}}}" style="width: 100%;"><br>
<a href="{{{pc_url_prefix}}}/object/name/Ayoola_Access_AccessInformation_Editor?pc_profile_info_to_edit=display_picture_base64" rel="spotlight"><span style="font-size:10px;">change photo</span></a></p>

<p><strong>{{{display_name}}}</strong></p>

<p>{{{profile_description}}}<span style="font-size:12px;"> <a href="{{{pc_url_prefix}}}/object/name/Ayoola_Access_AccessInformation_Editor" rel="spotlight">[edit]</a></span></p>

<hr>
<p><span style="font-size:10px;">Profile Page: <a href="{{{pc_url_prefix}}}/{{{username}}}" rel="spotlight">http://{{{pc_domain}}}{{{pc_url_prefix}}}/{{{username}}}</a></span></p>
',
  'advanced_parameter_value' => 
  array (
    0 => 'Ayoola_Access_Dashboard',
  ),
  'wrapper_name' => 'white-background',
  'markup_template_object_name' => 'Ayoola_Access_Dashboard',
) );

							}
							else
							{
								
$_68d3b303c9e476d9fed3cacb365c4e00 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_e20abf02bbd8b43b30074ed502d6d362 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h4>My Posts</h4>

<p><span style="font-size:12px;">Posts you created</span></p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-content-theme-border',
  '' => '',
) );

							}
							else
							{
								
$_e20abf02bbd8b43b30074ed502d6d362 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_2355eb238ba6b7b91bad00face0bfd21 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p><span style="font-size:10px;">{{{article_type}}}</span><br>
{{{article_title}}}<br>
<span style="font-size:10px;"><a href="{{{pc_url_prefix}}}{{{article_url}}}" rel="spotlight">View</a> - <a href="{{{pc_url_prefix}}}/object/name/Application_Article_Editor/?article_url={{{article_url}}}" rel="spotlight">Edit</a><a href="{{{pc_url_prefix}}}/article/post/editor/?article_url={{{article_url}}}" rel="spotlight"> </a>- <a href="{{{pc_url_prefix}}}/object/name/Application_Article_Delete/?article_url={{{article_url}}}" rel="spotlight">Delete</a></span></p>

<hr>',
  'advanced_parameter_value' => 
  array (
    0 => 'Application_Article_ShowAll',
    1 => '1',
    2 => '200',
    3 => 'You have not created any post yet. <a href=',
  ),
  'wrapper_name' => 'white-background',
  'markup_template_object_name' => 'Application_Article_ShowAll',
  'show_post_by_me' => '1',
  'no_of_post_to_show' => '200',
  'markup_template_no_data' => 'You have not created any post yet. <a href=',
) );

							}
							else
							{
								
$_2355eb238ba6b7b91bad00face0bfd21 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_36dc4afcedf5e47bc6e80e0ca8a3cdf6 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p><a class="pc-btn pc-btn-small pc-bg-color" href="/post/create" rel="spotlight">Create new post</a>&nbsp;<a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Ayoola_Access_AccessInformation_Editor?pc_profile_info_to_edit=post_categories" rel="spotlight">Manage Categories</a></p>
<div style="clear:both;"></div>',
  'advanced_parameter_value' => 
  array (
    0 => 'Ayoola_Access_Dashboard',
  ),
  'wrapper_name' => '',
  'markup_template_object_name' => 'Ayoola_Access_Dashboard',
) );

							}
							else
							{
								
$_36dc4afcedf5e47bc6e80e0ca8a3cdf6 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_b169f1c9adea6122c4d76373776f514c = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h4>Posts Types</h4>
<div style="clear:both;"></div>
<h4><span style="font-size:12px;">Other things you could post here</span></h4>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => 'white-content-theme-border',
  '' => '',
) );

							}
							else
							{
								
$_b169f1c9adea6122c4d76373776f514c = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_a2dd6abbc74cd3532e9f20a688e38e6f = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p>{{{post_type}}}<br><a href="{{{pc_url_prefix}}}/article/type/{{{post_type_id}}}" rel="spotlight" style="font-size: 11px; font-family: inherit;">Browse</a><span style="font-size: 11px; font-family: inherit;"> :: </span><a href="{{{pc_url_prefix}}}/tools/classplayer/?object_name=Application_Article_Creator&amp;article_type={{{post_type_id}}}" rel="spotlight" style="font-size: 11px; font-family: inherit;">Add New</a></p>

<hr>',
  'advanced_parameter_value' => 
  array (
    0 => 'Application_Article_Type_ShowAll',
    1 => 'Post types you could create will be displayed here as soon as they are defined by the site administrator.',
  ),
  'wrapper_name' => 'white-background',
  'markup_template_object_name' => 'Application_Article_Type_ShowAll',
  'markup_template_no_data' => 'Post types you could create will be displayed here as soon as they are defined by the site administrator.',
) );

							}
							else
							{
								
$_a2dd6abbc74cd3532e9f20a688e38e6f = null;

							}
							
							if( Ayoola_Page::hasPriviledge( array (
  0 => '99',
), array( 'strict' => true ) ) )
							{
								if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
								{
									
$_7efab3d724d18034974dfe843538068f = new Ayoola_Page_Editor_Text( array (
  'editable' => '<p><a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Application_Article_Type_List" rel="spotlight">Manage Post Types</a></p>
',
  'advanced_parameter_value' => 
  array (
    0 => 'Ayoola_Access_Dashboard',
  ),
  'object_access_level' => 
  array (
    0 => '99',
  ),
  'wrapper_name' => '',
  'markup_template_object_name' => 'Ayoola_Access_Dashboard',
) );

								}
								else
								{
									
$_7efab3d724d18034974dfe843538068f = null;

								}
							}    
							