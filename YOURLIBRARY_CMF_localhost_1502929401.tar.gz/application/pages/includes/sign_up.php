<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /sign_up
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: sign_up.php	Monday 14th of August 2017 08:37:13 AM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_7c7edaa21dc374f5da63f4dab70f3143 = new Ayoola_Menu( array (
  'option' => 'menu_4',
  'new_menu_name' => '',
  'template_name' => 'HorizontalWhite',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_7c7edaa21dc374f5da63f4dab70f3143 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Application_User_Creator' ) )
							{
								
$_0b5fac012ba37f25f8d5bbafdb4d5994 = new Application_User_Creator( array (
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_0b5fac012ba37f25f8d5bbafdb4d5994 = null;

							}
							