<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /about
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: about.php	Monday 14th of August 2017 08:55:36 AM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Menu' ) )
							{
								
$_829b71961ca48602c225d645bd23cfc8 = new Ayoola_Menu( array (
  'option' => 'menu_4',
  'new_menu_name' => '',
  'template_name' => 'HorizontalWhite',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_829b71961ca48602c225d645bd23cfc8 = null;

							}
							
							if( Ayoola_Loader::loadClass( 'Ayoola_Page_Editor_Text' ) )
							{
								
$_234a12d67c754944a719c2311490a683 = new Ayoola_Page_Editor_Text( array (
  'editable' => '<h1 style="text-align: center;"><strong><span style="color:#b22222;"><span style="font-family:Courier New,Courier,monospace;">ABOUT LIBRARY</span></span></strong></h1>

<p><strong><span style="color:#b22222;"><span style="font-family:Courier New,Courier,monospace;"><img alt="" src="/index.php/public/2017/08/14/20218241_jpg.jpg" style="width: 300px; height: 300px; float: left;"></span></span></strong></p>

<p>Yourlibrary gives you the platform to have access to several books you&nbsp;usually can not&nbsp;reach around you FREE!!!.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_234a12d67c754944a719c2311490a683 = null;

							}
							