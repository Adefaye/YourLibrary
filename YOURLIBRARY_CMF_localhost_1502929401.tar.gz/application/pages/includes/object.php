<?php
/**
* PageCarton Page Generator
*
* LICENSE
*
* @category PageCarton
* @package /object
* @generated Ayoola_Page_Editor_Layout
* @copyright  Copyright (c) PageCarton. (http://www.PageCarton.com)
* @license    http://www.PageCarton.com/license.txt
* @version $Id: object.php	Saturday 12th of August 2017 04:52:44 PM	 $ 
*/
//	Page Include Content

							if( Ayoola_Loader::loadClass( 'Ayoola_Object_Embed' ) )
							{
								
$_7402a8fc98735f6339d967236b27d461 = new Ayoola_Object_Embed( array (
  'editable' => 'Ayoola_Object_Play',
  'advanced_parameter_value' => 
  array (
    0 => '',
  ),
  'wrapper_name' => '',
  '' => '',
) );

							}
							else
							{
								
$_7402a8fc98735f6339d967236b27d461 = null;

							}
							