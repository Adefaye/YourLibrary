<?php return array (
  'ay__twosome10' => 'pageEditText',
  'ay__twosome10advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-background',
  'ay__twosome10editable' => '<h4>My Account Settings</h4>

<p><span style="font-size:12px;">Information you use to log on</span></p>
',
  'ay__twosome10_parameters' => 'advanced_parameters,editable',
  'ay__twosome11' => 'pageEditText',
  'ay__twosome11advanced_parameters' => 'advanced_parameter_name[]=markup_template_object_name&advanced_parameter_value[]=Ayoola_Access_Dashboard&wrapper_name=white-background',
  'ay__twosome11editable' => '<p><strong>First name</strong>: {{{firstname}}}<br>
<strong>Last name</strong>: {{{lastname}}}</p>

<p><strong>Email</strong>: {{{email}}}<br>
<strong>Password</strong>: ******</p>

<p><a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Application_User_Help_ChangePassword" rel="spotlight">Change Password</a>&nbsp;<a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Application_User_UserEmail_Editor" rel="spotlight">Manage Emails</a></p>
',
  'ay__twosome11_parameters' => 'advanced_parameters,editable',
  'ay__twosome20' => 'objectEmbed',
  'ay__twosome20advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-background',
  'ay__twosome20editable' => 'Application_User_Restrictions',
  'ay__twosome20_parameters' => 'advanced_parameters,editable',
  'ay__foursome10' => 'menuView',
  'ay__foursome10advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-content-theme-border',
  'ay__foursome10option' => 'MyAccount',
  'ay__foursome10new_menu_name' => '',
  'ay__foursome10template_name' => 'BlackAccordionSide-menu',
  'ay__foursome10_parameters' => 'advanced_parameters,option,new_menu_name,template_name',
  'ay__foursome20' => 'pageEditText',
  'ay__foursome20advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-content-theme-border',
  'ay__foursome20editable' => '<h4>My Profile</h4>

<p><span style="font-size:12px;">How people see you</span></p>
',
  'ay__foursome20_parameters' => 'advanced_parameters,editable',
  'ay__foursome21' => 'pageEditText',
  'ay__foursome21advanced_parameters' => 'advanced_parameter_name[]=markup_template_object_name&advanced_parameter_value[]=Ayoola_Access_Dashboard&wrapper_name=white-background',
  'ay__foursome21editable' => '<p style="text-align: center;"><img alt="Display Picture" src="{{{display_picture}}}" style="width: 100%;"><br>
<a href="{{{pc_url_prefix}}}/object/name/Ayoola_Access_AccessInformation_Editor?pc_profile_info_to_edit=display_picture_base64" rel="spotlight"><span style="font-size:10px;">change photo</span></a></p>

<p><strong>{{{display_name}}}</strong></p>

<p>{{{profile_description}}}<span style="font-size:12px;"> <a href="{{{pc_url_prefix}}}/object/name/Ayoola_Access_AccessInformation_Editor" rel="spotlight">[edit]</a></span></p>

<hr>
<p><span style="font-size:10px;">Profile Page: <a href="{{{pc_url_prefix}}}/{{{username}}}" rel="spotlight">http://{{{pc_domain}}}{{{pc_url_prefix}}}/{{{username}}}</a></span></p>
',
  'ay__foursome21_parameters' => 'advanced_parameters,editable',
  'ay__foursome30' => 'pageEditText',
  'ay__foursome30advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-content-theme-border',
  'ay__foursome30editable' => '<h4>My Posts</h4>

<p><span style="font-size:12px;">Posts you created</span></p>
',
  'ay__foursome30_parameters' => 'advanced_parameters,editable',
  'ay__foursome31' => 'pageEditText',
  'ay__foursome31advanced_parameters' => 'advanced_parameter_name[]=markup_template_object_name&advanced_parameter_value[]=Application_Article_ShowAll&advanced_parameter_name[]=show_post_by_me&advanced_parameter_value[]=1&advanced_parameter_name[]=no_of_post_to_show&advanced_parameter_value[]=200&advanced_parameter_name[]=markup_template_no_data&advanced_parameter_value[]=You%20have%20not%20created%20any%20post%20yet.%20%3Ca%20href%3D&wrapper_name=white-background',
  'ay__foursome31editable' => '<p><span style="font-size:10px;">{{{article_type}}}</span><br>
{{{article_title}}}<br>
<span style="font-size:10px;"><a href="{{{pc_url_prefix}}}{{{article_url}}}" rel="spotlight">View</a> - <a href="{{{pc_url_prefix}}}/object/name/Application_Article_Editor/?article_url={{{article_url}}}" rel="spotlight">Edit</a><a href="{{{pc_url_prefix}}}/article/post/editor/?article_url={{{article_url}}}" rel="spotlight"> </a>- <a href="{{{pc_url_prefix}}}/object/name/Application_Article_Delete/?article_url={{{article_url}}}" rel="spotlight">Delete</a></span></p>

<hr>',
  'ay__foursome31_parameters' => 'advanced_parameters,editable',
  'ay__foursome32' => 'pageEditText',
  'ay__foursome32advanced_parameters' => 'advanced_parameter_name[]=markup_template_object_name&advanced_parameter_value[]=Ayoola_Access_Dashboard&wrapper_name=',
  'ay__foursome32editable' => '<p><a class="pc-btn pc-btn-small pc-bg-color" href="/post/create" rel="spotlight">Create new post</a>&nbsp;<a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Ayoola_Access_AccessInformation_Editor?pc_profile_info_to_edit=post_categories" rel="spotlight">Manage Categories</a></p>
<div style="clear:both;"></div>',
  'ay__foursome32_parameters' => 'advanced_parameters,editable,editable',
  'ay__foursome40' => 'pageEditText',
  'ay__foursome40advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-content-theme-border',
  'ay__foursome40editable' => '<h4>Posts Types</h4>
<div style="clear:both;"></div>
<h4><span style="font-size:12px;">Other things you could post here</span></h4>
',
  'ay__foursome40_parameters' => 'advanced_parameters,editable',
  'ay__foursome41' => 'pageEditText',
  'ay__foursome41advanced_parameters' => 'advanced_parameter_name[]=markup_template_object_name&advanced_parameter_value[]=Application_Article_Type_ShowAll&advanced_parameter_name[]=markup_template_no_data&advanced_parameter_value[]=Post%20types%20you%20could%20create%20will%20be%20displayed%20here%20as%20soon%20as%20they%20are%20defined%20by%20the%20site%20administrator.&wrapper_name=white-background',
  'ay__foursome41editable' => '<p>{{{post_type}}}<br><a href="{{{pc_url_prefix}}}/article/type/{{{post_type_id}}}" rel="spotlight" style="font-size: 11px; font-family: inherit;">Browse</a><span style="font-size: 11px; font-family: inherit;"> :: </span><a href="{{{pc_url_prefix}}}/tools/classplayer/?object_name=Application_Article_Creator&amp;article_type={{{post_type_id}}}" rel="spotlight" style="font-size: 11px; font-family: inherit;">Add New</a></p>

<hr>',
  'ay__foursome41_parameters' => 'advanced_parameters,editable',
  'ay__foursome42' => 'pageEditText',
  'ay__foursome42advanced_parameters' => 'advanced_parameter_name[]=markup_template_object_name&advanced_parameter_value[]=Ayoola_Access_Dashboard&object_access_level[]=99&wrapper_name=',
  'ay__foursome42editable' => '<p><a class="pc-btn pc-btn-small" href="{{{pc_url_prefix}}}/object/name/Application_Article_Type_List" rel="spotlight">Manage Post Types</a></p>
',
  'ay__foursome42_parameters' => 'advanced_parameters,editable,editable',
  'section_list' => 'ay__twosome1,ay__twosome2,ay__foursome1,ay__foursome2,ay__foursome3,ay__foursome4,',
);