<?php return array (
  'ay__oneness0' => 'pageEditText',
  'ay__oneness0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__oneness0editable' => '<h1>Create an account</h1>

<p>&nbsp;</p>
',
  'ay__oneness0_parameters' => 'advanced_parameters,editable,editable',
  'ay__middlebar0' => 'userSignup',
  'ay__middlebar0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-background',
  'ay__middlebar0_parameters' => 'advanced_parameters',
  'section_list' => 'ay__oneness,ay__middlebar,',
);