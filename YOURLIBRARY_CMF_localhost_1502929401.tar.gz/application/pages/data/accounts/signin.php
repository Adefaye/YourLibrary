<?php return array (
  'ay__oneness0' => 'pageEditText',
  'ay__oneness0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-background',
  'ay__oneness0editable' => '<p></p>
<h1>Login</h1>
',
  'ay__oneness0_parameters' => 'advanced_parameters,editable',
  'ay__oneness1' => 'accessLogin',
  'ay__oneness1advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-background',
  'ay__oneness1_parameters' => 'advanced_parameters',
  'ay__oneness2' => 'pageEditText',
  'ay__oneness2advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__oneness2editable' => '<hr>
<p>Forgot Password? <a href="/object/name/Application_User_Help_ForgotUsernameOrPassword">Sign in Help</a>!</p>
',
  'ay__oneness2_parameters' => 'advanced_parameters,editable,editable',
  'section_list' => 'ay__oneness,',
);