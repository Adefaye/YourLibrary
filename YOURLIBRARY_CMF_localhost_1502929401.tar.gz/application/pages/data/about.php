<?php return array (
  'ay__oneness0' => 'menuView',
  'ay__oneness0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__oneness0option' => 'menu_4',
  'ay__oneness0new_menu_name' => '',
  'ay__oneness0template_name' => 'HorizontalWhite',
  'ay__oneness0_parameters' => 'advanced_parameters,option,new_menu_name,template_name,option,new_menu_name,template_name',
  'ay__oneness1' => 'pageEditText',
  'ay__oneness1advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__oneness1editable' => '<h1 style="text-align: center;"><strong><span style="color:#b22222;"><span style="font-family:Courier New,Courier,monospace;">ABOUT LIBRARY</span></span></strong></h1>

<p><strong><span style="color:#b22222;"><span style="font-family:Courier New,Courier,monospace;"><img alt="" src="/index.php/public/2017/08/14/20218241_jpg.jpg" style="width: 300px; height: 300px; float: left;"></span></span></strong></p>

<p>Yourlibrary gives you the platform to have access to several books you&nbsp;usually can not&nbsp;reach around you FREE!!!.</p>

<p>&nbsp;</p>

<p>&nbsp;</p>
',
  'ay__oneness1_parameters' => 'advanced_parameters,editable,editable',
  'section_list' => 'ay__oneness,',
);