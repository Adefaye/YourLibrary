<?php return array (
  'ay__middlebar0' => 'pageEditText',
  'ay__middlebar0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__middlebar0editable' => '<h1>Posts</h1><div><br></div>
',
  'ay__middlebar0_parameters' => 'advanced_parameters,editable,editable',
  'ay__middlebar1' => 'articleShowAll',
  'ay__middlebar1advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__middlebar1option' => '20',
  'ay__middlebar1category_name' => '',
  'ay__middlebar1article_types' => '',
  'ay__middlebar1template_name' => '',
  'ay__middlebar1_parameters' => 'advanced_parameters,option,category_name,article_types,template_name,option,category_name,article_types,template_name',
  'section_list' => 'ay__middlebar,',
);