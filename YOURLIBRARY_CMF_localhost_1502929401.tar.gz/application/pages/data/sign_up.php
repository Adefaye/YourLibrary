<?php return array (
  'ay__oneness0' => 'menuView',
  'ay__oneness0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__oneness0option' => 'menu_4',
  'ay__oneness0new_menu_name' => '',
  'ay__oneness0template_name' => 'HorizontalWhite',
  'ay__oneness0_parameters' => 'advanced_parameters,option,new_menu_name,template_name,option,new_menu_name,template_name',
  'ay__middlebar0' => 'userSignup',
  'ay__middlebar0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__middlebar0_parameters' => 'advanced_parameters',
  'section_list' => 'ay__oneness,ay__middlebar,',
);