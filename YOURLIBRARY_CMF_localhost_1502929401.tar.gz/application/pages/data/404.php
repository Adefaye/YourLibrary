<?php return array (
  'ay__oneness0' => 'pageEditText',
  'ay__oneness0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=well',
  'ay__oneness0editable' => '<h1>Error 404 - Page Not Found</h1>
',
  'ay__oneness0_parameters' => 'advanced_parameters,editable,editable',
  'ay__oneness1' => 'pageEditText',
  'ay__oneness1advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=white-background',
  'ay__oneness1editable' => '<p>You are seeing this page because you have requested a page that is not available. Please check the URL and try again.</p>
',
  'ay__oneness1_parameters' => 'advanced_parameters,editable,editable',
  'ay__oneness2' => 'objectEmbed',
  'ay__oneness2advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__oneness2editable' => 'Ayoola_Page_AutoCreator',
  'ay__oneness2_parameters' => 'advanced_parameters,editable,editable',
  'section_list' => 'ay__oneness,',
);