<?php return array (
  'ay__middlebar0' => 'objectEmbed',
  'ay__middlebar0advanced_parameters' => 'advanced_parameter_name[]=&advanced_parameter_value[]=&wrapper_name=',
  'ay__middlebar0editable' => 'Ayoola_Object_Play',
  'ay__middlebar0_parameters' => 'advanced_parameters,editable,editable',
  'section_list' => 'ay__middlebar,',
);